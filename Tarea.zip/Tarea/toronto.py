#Creamos el archivo de la APP en el interprete principal (Python)

##########################################
#Importamos librerias
import streamlit as st
import plotly.express as px
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

##########################################
#Definimos la instancia
@st.cache_resource

##########################################
#Creamos la función de carga de datos 
def load_data():
    #Lectura de archivo csv
    df = pd.read_csv("Toronto_view_1.csv")

    #Selecciono las columnas tipo numericas del dataframe
    numeric_df = df.select_dtypes(['float','int']) 
    numeric_cols = numeric_df.columns             

    #Selecciono las columnas tipo texto del dataframe
    text_df = df.select_dtypes(['object']) 
    text_cols = text_df.columns          

    #Selecciono algunas columnas categoricas de valores para desplegar 
    categorical_column_room = df['room_type']
    #obtengo los valores unicos de la columna categorica seleccionada
    unique_categories_room = categorical_column_room.unique()

    return df, numeric_cols, text_cols, unique_categories_room, numeric_df

####################################################################
#Cargo los datos obtenidos de la función "load_data"
df, numeric_cols, text_cols, unique_categories_room, numeric_df = load_data()

st.markdown('<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">', unsafe_allow_html=True)

#########################################################################
#CREACIÓN DEL DASHBOARD
#Generamos las páginas que utilizaremos en el diseño

#Widget 1: Selectbox
#Menu desplegable de opciones de las páginas seleccionadas
View= st.selectbox(label= "View", options= ["Información", "Modelado explicativo", "Modelado predictivo"])

###########################################################################################################################################

# CONTENIDO DE LA VISTA 1
if View == "Información":
    #Generamos los encabezados para el dashboard
    st.markdown("<h1 style = 'text-align:center; color:#1E3A8A;'> AIRBNB en Toronto, Canadá 🍁</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='text-align:center;'>Explora alojamientos, precios y atracciones de una de las ciudades más lindas del mundo.</h4>", unsafe_allow_html=True)

    ##############################################################################
    #Genereamos los encabezados para la barra lateral (sidebar)
    st.sidebar.title("DASHBOARD")
    st.sidebar.header("Sidebar: Panel de selección")

    ####################################################################
    #Introducción a Toronto 
    st.markdown("""
    <p style='font-size: 18px; line-height: 1.4; margin-bottom: 20px;'>
        Toronto es la capital de Ontario y la ciudad más grande de Canadá. Se encuentra en la costa noroeste del lago Ontario y es un centro económico, cultural y turístico de primer nivel.
    </p>
    """, unsafe_allow_html=True)

    st.markdown("### ¿Dónde se encuentra?")

    # Mostramos un mapa donde resaltamos la ciudad de Toronto 
    import folium
    from streamlit_folium import st_folium

    # Crear un mapa del mundo centrado en el ecuador
    mapa = folium.Map(location=[43.70643, -79.39864], zoom_start=9)
    
    folium.Marker( # Agregar un marcador para Toronto
        location=[43.70643, -79.39864],
        popup='Toronto 🇨🇦',
        icon=folium.Icon(color='red', icon='info-sign')
    ).add_to(mapa)

    folium.Circle(  # Agregar un círculo para resaltar la ciudad
        radius=7000,  
        location=[43.70643, -79.39864],
        color='crimson',
        fill=True,
        fill_color='crimson',
        fill_opacity=0.3
    ).add_to(mapa)

    # Mostrar el mapa en Streamlit
    st_folium(mapa, width=800, height=450)

    ####################################################
    #Mostramos más información 
    with st.expander("Datos interesantes de Toronto"):
        st.markdown("""
        <div style='font-size: 18px; line-height: 1.4; margin-bottom: 20px;'>
            <h3 style='color: #061f4e; font-size: 24px; font-weight: bold; margin-bottom: 10px;'>🇨🇦 ¿Sabías que...?</h3>
            <ul style='padding-left: 20px; line-height: 1.5; font-size: 18px;'>
                <li><b>Toronto es la ciudad más multicultural del mundo</b>: ¡Más del 50% de sus habitantes nacieron fuera de Canadá!</li>
                <li>Es el <b>hogar de más de 200 grupos étnicos</b> y se hablan más de <b>160 idiomas</b>.</li>
                <li>Su población es de más de <b>2.6 millones de habitantes</b.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
            
        st.markdown("""
        <div style='font-size: 18px; line-height: 1.2; margin-bottom: 20px;'>
            <h3 style='color: #061f4e; font-size: 24px; font-weight: bold; margin-bottom: 10px;'>🍽 Gastronomía típica</h3>
            <ul style='padding-left: 20px; line-height: 1.5; font-size: 18px;'>
                <li><b>Peameal bacon sandwich:</b> un clásico de los mercados de Toronto.</li>
                <li><b>Butter tarts:</b> pequeñas tartaletas dulces, ¡una delicia canadiense!</li>
                <li><b>Poutine:</b> papas fritas con queso y gravy, típico de todo Canadá, pero muy popular en la ciudad.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        col1, col2, col3 = st.columns(3)

        with col1:
            st.image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSA__CGjyZd7_3adyenzXbyUCDXTRiGGx-8CA&s", 
                        caption="Peameal Bacon Sandwich", use_container_width=True)

        with col2:
            st.image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqzH8bYrjx-2VVz_mC2qYbZ6Z6Hmi9Oif6sg&s", 
                        caption="Butter Tarts", use_container_width=True)

        with col3:
            st.image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTD3NfLZzwIKblYpxqSKQZNyDUOCnqYrnwZIw&s", 
                        caption="Poutine", use_container_width=True)

        st.markdown("""
        <div style='font-size: 18px; line-height: 1.2; margin-bottom: 20px;'>
            <h3 style='color: #061f4e; font-size: 24px; font-weight: bold; margin-bottom: 10px;'>🎭 Cultura y entretenimiento</h3>
            <ul style='padding-left: 20px; line-height: 1.5; font-size: 18px;'>
                <li>Toronto es sede del <b>Festival Internacional de Cine de Toronto (TIFF)</b>, uno de los más prestigiosos del mundo.</li>
                <li>Tiene <b>más de 80 museos</b>, incluyendo el enorme Royal Ontario Museum y el Art Gallery of Ontario.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div style='font-size: 18px; line-height: 1.2; margin-bottom: 20px;'>
            <h3 style='color: #061f4e; font-size: 24px; font-weight: bold; margin-bottom: 10px;'>🎉 Tradiciones y celebraciones</h3>
            <ul style='padding-left: 20px; line-height: 1.5; font-size: 18px;'>
                <li><b>Caribana Festival</b> (julio/agosto): un colorido desfile caribeño con música, danza y cultura afrocaribeña.</li>
                <li><b>Toronto Pride</b> (junio): uno de los festivales del orgullo LGBTQ+ más grandes del mundo.</li>
                <li><b>Nuit Blanche</b> (octubre): una noche entera de arte contemporáneo, con exposiciones al aire libre y performances por toda la ciudad.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div style='font-size: 18px; line-height: 1.2; margin-bottom: 20px;'>
            <h3 style='color: #061f4e; font-size: 24px; font-weight: bold; margin-bottom: 10px;'>🌡 Clima</h3>
            <ul style='padding-left: 20px; line-height: 1.5; font-size: 18px;'>
                <li>Toronto tiene un <b>clima continental húmedo</b>, con <b>inviernos fríos y nevados</b> (temperaturas promedio de -5 °C en enero).</li>
                <li>Los <b>veranos son cálidos y soleados</b>, con temperaturas entre 25-30 °C en julio.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

        import plotly.graph_objects as go

        # Datos de temperaturas promedio en Toronto
        meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
        mes = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
        temperaturas = [-5, -3, 2, 9, 15, 20, 23, 22, 18, 11, 5, -2]

        # Crear degradado de colores según temperatura
        colors = ['#1f77b4' if temp <= 10 else '#ff7f0e' for temp in temperaturas]  # Azul para frío, naranja para calor

        # Crear figura
        fig = go.Figure()

        fig.add_trace(go.Scatter(
            x=meses,
            y=temperaturas,
            customdata = mes,
            mode='markers+lines',
            marker=dict(
                size=10,
                color=colors, 
                line=dict(width=2, color='DarkSlateGrey')
            ),
            line=dict(color='lightgrey', width=2, dash='dash'), 
            name='Temp. Promedio',
            hovertemplate = 
                '<b>%{customdata}</b><br>'     #Mostramos el mes
                'Temperatura: %{y}°C<br>'   #Mostramos la temperatura 
                '<extra></extra>'
        ))

        # Ajustes de estilo
        fig.update_layout(
            title="Evolución de temperaturas en Toronto",
            title_font=dict(size=16, family="Verdana", color="black"),
            xaxis_title="Mes",
            yaxis_title="Temperatura (°C)",
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=True, gridcolor='Gainsboro'),
            template="plotly_white",
            height=450,
            plot_bgcolor='rgba(0,0,0,0)',
        )

        # Mostrar en Streamlit
        st.plotly_chart(fig, use_container_width=True)
    
    #############################################################################
    #Mostramos lugares 

    st.markdown("""<h2 style="color:#1E3A8A; text-align:center;">LUGARES DESTACADOS</h2>""", unsafe_allow_html=True)

    # Estilo de la tarjeta
    flip_card_css = """
    <style>
    .flip-card {
        background-color: transparent;
        width: 100%;
        height: 320px;
        perspective: 1000px;
        margin: auto;
    }

    .flip-card-inner {
        position: relative;
        width: 100%;
        height: 100%;
        text-align: center;
        transition: transform 0.8s cubic-bezier(0.4, 0.2, 0.2, 1);
        transition: transform 0.6s;
        transform-style: preserve-3d;
        border-radius: 20px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
    }

    .flip-card:hover .flip-card-inner {
        transform: rotateY(180deg);
    }

    .flip-card-front, .flip-card-back {
        position: absolute;
        width: 100%;
        height: 100%;
        -webkit-backface-visibility: hidden;
        backface-visibility: hidden;
        border-radius: 20px;
        overflow: hidden;
    }

    .flip-card-front {
        background-color: #f0f4f8;
    }

    .flip-card-front img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .flip-card-back {
        background: linear-gradient(135deg, #dbeafe, #bfdbfe);
        color: #1e3a8a;
        transform: rotateY(180deg);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 25px;
    }

    .flip-card-back h2 {
        margin: 0;
        font-size: 26px;
        font-weight: bold;
    }

    .flip-card-back p {
        font-size: 18px;
        margin-top: 10px;
    }
    </style>    
    """

    # Mostrar el estilo
    st.markdown(flip_card_css, unsafe_allow_html=True)

    # Lista de lugares
    lugares = [
        {
            "url": "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0d/42/89/9e/photo0jpg.jpg?w=1200&h=-1&s=1",
            "nombre": "Torre CN",
            "descripcion": "Símbolo icónico de Toronto con una vista panorámica espectacular desde su mirador de cristal."
        },
        {
            "url": "https://d1l57x9nwbbkz.cloudfront.net/files/s3fs-public/2024-06/ripleys-aquarium-shark-tunnel.jpg?VersionId=FFzqCSprkFrgXm7hEbIkNZyCRUWmctYn",
            "nombre": "Acuario de Ripley",
            "descripcion": "Uno de los acuarios más impresionantes de Canadá, hogar de miles de criaturas marinas."
        },
        {
            "url": "https://tecnne.com/wp-content/uploads/2015/11/Daniel-Libeskind-Ampliacion-del-Museo-Real-de-Ontario-tecnne.jpg",
            "nombre": "Museo Real de Ontario",
            "descripcion": "Un museo de renombre mundial con exposiciones sobre historia natural, cultura mundial y arte."
        },
        {
            "url": "https://www.toronto2anywhere.ca/wp-content/uploads/2025/01/Toronto-Casa-Loma-in-Spring.jpg",
            "nombre": "Casa Loma",
            "descripcion": "Un castillo histórico en el corazón de Toronto, lleno de elegancia, jardines impresionantes y túneles secretos."
        },
    ]

    # Función para mostrar cada lugar
    def mostrar_lugar(col, url, nombre, descripcion):
        flip_card_html = f"""
        <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                    <img src="{url}" alt="Imagen">
                </div>
                <div class="flip-card-back">
                    <h2>{nombre}</h2>
                    <p>{descripcion}</p>
                </div>
            </div>
        </div>
        """
        col.markdown(flip_card_html, unsafe_allow_html=True)

    # Mostrar en 2 columnas
    for i in range(0, len(lugares), 2):
        cols = st.columns(2)
        for j in range(2):
            if i + j < len(lugares):
                lugar = lugares[i + j]
                mostrar_lugar(cols[j], lugar["url"], lugar["nombre"], lugar["descripcion"])

        st.markdown("<br>", unsafe_allow_html=True)
    

##########################################################################################################################################
    #Widget 2: Checkbox 
    st.sidebar.subheader("BD de Airbnb")
    #Generamos un cuadro de selección en una barra lateral(sidebar) para mostrar Dataset 
    check_box = st.sidebar.checkbox(label = "Mostrar Dataset")

    #Condicional para que aparezca el DataFrame
    if check_box:
        st.write(df)
        st.write(df.columns)
        st.write(df.describe())

###########################################################################################################################################
###########################################################################################################################################

# CONTENIDO DE LA VISTA 2
if View == "Modelado explicativo":
    #Generamos los encabezados para el dashboard
    st.markdown("<h1 style = 'text-align:center; color:#1E3A8A;'> AIRBNB en Toronto, Canadá 🍁</h1>", unsafe_allow_html=True)
##############################################################################
    #Genereamos los encabezados para la barra lateral (sidebar)
    st.sidebar.title("DASHBOARD")
    st.sidebar.header("Sidebar: Panel de selección")

    #Sección de análisis
    section = st.sidebar.selectbox(
        "Seleccione el análisis que desea ver:",
        ["Análisis univariado", "Análisis de precios"]
    )

    #################################################################################
    if section == "Análisis univariado":
        vars_interes = {
            'host_response_time': 'Host_response_rate',
            'host_is_superhost': 'Host_is_superhost',
            'room_type': 'Room_type',
            'neighbourhood_cleansed': 'Neighbourhood_cleansed',
            'instant_bookable': 'Instant_bookable',
        }

        ################################################################        
        #Sidebar: selección de variables
        # Selección de variable
        st.sidebar.subheader("Análisis univariado")
        var_cod = st.sidebar.selectbox("📌 Variable a analizar:", options=list(vars_interes.keys()), format_func=lambda x: vars_interes[x])

        # Filtros
        with st.expander("🔧 Filtros adicionales", expanded=False):
            col1, col2 = st.columns(2)
            with col1:
                filtro_vecindario = st.selectbox(
                    "Filtrar por vecindario:",
                    options=['Todos'] + sorted(df['neighbourhood_cleansed'].dropna().unique().tolist())
                )
            with col2:
                rango_precio = st.slider("Filtrar por precio (CAD):", 0, int(df['price'].max()), (0, 300))

        # Aplicación de filtros
        df_filt = df.copy()
        if filtro_vecindario != 'Todos':
            df_filt = df_filt[df_filt['neighbourhood_cleansed'] == filtro_vecindario]
        df_filt = df_filt[df_filt['price'].between(*rango_precio)]

        # Limpieza de datos
        valores_excluir = ['Sin tiempo', 'False']
        df_filt = df_filt[~df_filt[var_cod].isin(valores_excluir)]

        # Cuerpo principal
        st.markdown(f"### 🔍 Análisis de *{vars_interes[var_cod]}*")

        col1, col2 = st.columns(2)
        # Paleta personalizada entre azul y morado
        custom_palette = ['#008BD0', '#9A99E1', '#703B94', '#009EFF', '#C4B5FD', '#E0E7FF']

        # Gráfico de barras (frecuencia absoluta)
        with col1:
            st.markdown("Frecuencia absoluta")
            frecuencia_abs = df_filt[var_cod].value_counts().reset_index()
            frecuencia_abs.columns = [var_cod, 'Frecuencia']
            fig_bar = px.bar(
                frecuencia_abs,
                x='Frecuencia',
                y=var_cod,
                color=var_cod,
                color_discrete_sequence=custom_palette,
                labels={var_cod: vars_interes[var_cod]}
            )
            st.plotly_chart(fig_bar, use_container_width=True)

        # Gráfico circular (frecuencia relativa)
        with col2:
            st.markdown("Porcentaje (%)")
            frecuencia_rel = df_filt[var_cod].value_counts(normalize=True).mul(100).round(1)
            fig_pie = px.pie(
                names=frecuencia_rel.index,
                values=frecuencia_rel.values,
                color_discrete_sequence=custom_palette,
                hole=0.4
            )
            st.plotly_chart(fig_pie, use_container_width=True)

        # Tabla de frecuencias
        with st.expander("📋 Ver tabla de frecuencias"):
            tabla = df_filt[var_cod].value_counts().reset_index()
            tabla.columns = [vars_interes[var_cod], "Frecuencia"]
            st.dataframe(tabla)
            
    ##############################################################################################################
    elif section == "Análisis de precios":
        #Convertir la moneda 
        conversion = 14.05            #Modificar la moneda 
        currency = st.sidebar.radio("Selecciona la moneda: ",["Dólares canadienses (CAD)", "Pesos mexicanos (MXN)"])
        unidad = "MXN" if "MXN" in currency else "CAD"

        #Establecemos la función 
        def convertir(precio):
            return precio * conversion if unidad == "MXN" else precio 

        #Aplicamos la conversion 
        df["converted_price"] = df["price"].apply(convertir)

        #Obtenemos la media 
        media = df["converted_price"].mean()
        rango_in = int(media * 0.5)
        rango_sup = int(media * 1.5)

        #Obtenemos min y max
        min_val = int(df["converted_price"].min())
        max_val = int(df["converted_price"].max())

        #Mostramos un slider
        price_range = st.sidebar.slider("Rango de precios:", min_val, max_val, (rango_in, rango_sup))

        #Tipo de cuarto
        room_types = st.sidebar.multiselect(
            "Tipo de propiedad:",
            options = df["room_type"].unique()
        )

        #Filtramos los datos 
        filtered_df = df[
            (df["converted_price"] >= price_range[0]) & 
            (df["converted_price"] <= price_range[1]) & 
            (df["room_type"].isin(room_types))
        ]

        ##############################################################################################################
        #Información 
        st.markdown("""
            <style>
                .title {
                    font-family: 'Arial', sans-serif;  
                    font-size: 22px; 
                    font-weight: 500;  
                    color: #411A8D !important;  
                    text-align: center;  
                    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1); 
                    margin-top: 10px;
                    margin-bottom: 10px;  
                }
            </style>
            <h3 class="title"> Análisis de Precios en Airbnb</h3>
        """, unsafe_allow_html=True)

        #Creamos tabs
        tab1, tab2, tab3 = st.tabs(["📋 KPIs de precios", "📊 Gráficos", "🏙️ Barrios Caros y Baratos"])

        # Personalizar los tabs con CSS
        st.markdown("""
            <style>
                .stTabs {  
                    font-size: 19px;  
                    font-weight: 600;  
                    color: #201C6D; 
                }

                /* Cambiar la línea debajo de los tabs */
                .stTabs > div > div:first-child {  
                    border-bottom: 4px solid #2D198E; 
                }

                /* Cambiar el color del tab seleccionado */
                .stTab > div > div > div > div:hover { 
                    background-color: #E0E7FF;
                    color: #490a65;   
                }

                /* Estilo de hover para los tabs */
                .stTab > div > div > div > div {
                    color: #490a65;  
                    cursor: pointer;  
                }
            </style>
        """, unsafe_allow_html=True)
########################################################################3
        #Mostramos KPIs
        with tab1:   
            # Calculamos la moda de los precios, con validación para evitar el error
            precio_moda = filtered_df['converted_price'].mode()

            # Si la moda está vacía, asignamos un valor por defecto
            if not precio_moda.empty:
                precio_moda = precio_moda.iloc[0]
            else:
                precio_moda = 0   

            html_kpi = """
            <style>
                .kpi-container {{
                    display: flex;
                    justify-content: center;
                    flex-wrap: wrap;
                    gap: 2rem;
                    margin-top: 2.5rem;
                    margin-bottom: 2.5rem;
                }}
                .kpi-card {{
                    background-color: #EEF2FF;
                    border-radius: 15px;
                    padding: 30px;
                    width: 300px;
                    text-align: center;
                    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
                    transition: all 0.3s ease;
                }}
                .kpi-card:hover {{
                    background-color: #E0E7FF;
                    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
                    transform: translateY(-8px);
                }}
                .kpi-title {{
                    font-size: 20px;
                    color: #2D198E;
                    font-weight: 600;
                    margin-bottom: 12px;
                    transition: color 0.3s ease;;
                }}
                .kpi-value {{
                    font-size: 36px;
                    font-weight: bold;
                    color: #490a65;
                    transition: color 0.3s ease;
                }}
                .kpi-card:hover .kpi-title {{
                    color: #1C0D82;
                }}
                .kpi-card:hover .kpi-value {{
                    color: #311B92;
                }}
            </style>
    
            <div class="kpi-container">
                <div class="kpi-card">
                    <div class="kpi-title">💵 Precio Promedio</div>
                    <div class="kpi-value">{precio_promedio} {unidad}</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-title">📊 Mediana del Precio</div>
                    <div class="kpi-value">{mediana_precio} {unidad}</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-title">📈 Desviación Estándar</div>
                    <div class="kpi-value">{desviacion_estandar} {unidad}</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-title">📈 Precio Más Frecuente</div>
                    <div class="kpi-value">{precio_moda} {unidad}</div>
                </div>
            </div>
            """.format(
                precio_promedio=f"{filtered_df['converted_price'].mean():,.2f}",
                mediana_precio=f"{filtered_df['converted_price'].median():,.2f}",
                desviacion_estandar=f"{filtered_df['converted_price'].std():,.2f}",
                precio_moda=f"{precio_moda:,.2f}",
                unidad=unidad
            )

            st.markdown(html_kpi, unsafe_allow_html=True)
        
            #Gráfico del precio promedio por tipo de propiedad
            fig_roomtype = px.bar(
                filtered_df.groupby("room_type")["converted_price"].mean().reset_index(),
                x="room_type",
                y="converted_price",
                color="room_type",
                title="Precio promedio por tipo de propiedad",
                labels={"converted_price": f"Precio promedio ({unidad})"},
                color_discrete_sequence=["#1E1A84", "#411A8D", "#23389F"]
            )
            fig_roomtype.update_layout(
                template="simple_white",
                xaxis_title="Tipo de propiedad",
                yaxis_title=f"Precio promedio ({unidad})",
                showlegend=False
            )
            st.plotly_chart(fig_roomtype, use_container_width=True)
########################################################################################
        with tab2: 
            st.markdown("<h2 style='text-align: center; color: #201C6D;'> Análisis de Distribución</h2>", unsafe_allow_html=True)

            #Establecemos una paleta de colores para los graficos 
            color_palette = ["#1E1A84", "#411A8D", "#23389F"]
            
            #Creamos el histograma
            fig_hist = px.histogram(
                filtered_df,
                x= "converted_price",
                nbins = 50,
                color_discrete_sequence = [color_palette[0]],
                title = "Histograma de precios",
                labels = {"converted_price": f"Precio ({unidad})"},
                template = "plotly_white",
            )
            fig_hist.update_layout(
                height=500,
                bargap=0.2
            )

            #Creamos el boxplot
            fig_box = px.box(
                filtered_df,
                x= "room_type",
                y = "converted_price",
                color_discrete_sequence = [color_palette[1]],
                title = "Precios por tipo de habitación",
                labels = {"converted_price": f"Precio ({unidad})", "room_type": "Tipo de habitación"},
                template = "plotly_white",
            )
            fig_box.update_layout(height=500)

            # Creamos el scatter plot
            fig_scatter = px.scatter(
                filtered_df,
                x="converted_price",
                y="minimum_nights",  
                title="Relación Precio vs Noches mínimas",
                labels={"converted_price": "price", "minimum_nights": "minimum_nights"},
                template="plotly_white",
            )
            fig_scatter.update_traces(marker=dict(color='#23389F'))
            fig_scatter.update_layout(height=600)

            # Mostramos en la grilla
            st.markdown("""
            <style>
                .full-width-container {
                    width: 100%;
                    padding-left: 1rem;
                    padding-right: 1rem;
                }
                .grid-container {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    grid-gap: 30px;
                }
                .full-row {
                    grip-column: 1 / 3;
                }
            </style>
            """, unsafe_allow_html=True)
            
            #Creamos las columnas 
            col1, col2 = st.columns([1,1])

            with col1:
                st.plotly_chart(fig_hist, use_container_width=True)
            
            with col2: 
                st.plotly_chart(fig_box, use_container_width=True)
            
            st.plotly_chart(fig_scatter, use_container_width=True)
##############################################################################################
        with tab3: 
            st.markdown("""
                <h2 style='
                    text-align: center; 
                    color: #201C6D; 
                    font-family: "Arial", sans-serif; 
                    text-shadow: 1px 1px 2px #d1d5db; 
                    margin-bottom: 2rem;'> 
                    Barrios Caros y Baratos
                </h2>
                <style>
                    .card-container {{
                        background-color: #EEF2FF;
                        padding: 30px;
                        border-radius: 20px;
                        box-shadow: 0 8px 16px rgba(79,70,229,0.2);
                        text-align: center;
                        height: 200px;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        transition: all 0.3s ease;
                        margin-bottom: 1rem;
                    }}
                    .card-container:hover {{
                        background-color: #E0E7FF;
                        box-shadow: 0 12px 24px rgba(79,70,229,0.3);
                        transform: translateY(-8px);
                    }}
                </style>
                """, unsafe_allow_html=True)
            
            #Definimos los umbrales
            cheap_threshold = min_val + (max_val - min_val) * 0.3
            expensive_threshold = min_val + (max_val - min_val) * 0.7

            cheap_places = filtered_df[filtered_df["converted_price"] <= cheap_threshold]
            expensive_places = filtered_df[filtered_df["converted_price"] >= expensive_threshold]

            #Evitamos divisiones entre 0
            if len(filtered_df) > 0:
                cheap_percentage = len(cheap_places) / len(filtered_df) * 100
                expensive_percentage = len(expensive_places) / len(filtered_df) * 100
            else:
                cheap_percentage = 0
                expensive_percentage = 0

            #Creamos las columnas
            col4, col5 = st.columns(2, gap="large")

            #Alojamientos caros y baratos
            with col4:
                st.markdown(f"""
                    <div class = "kpi-card">
                        <h3 style="color: #2D198E; font-size: 24px;">🏡 Alojamientos baratos</h3>
                        <h1 style="color: #490a65; font-size: 48px;">{len(cheap_places)}</h1>
                        <p style="color: #6B7280; font-size: 18px;">({cheap_percentage:.1f}%)</p>
                    </div>
                """, unsafe_allow_html=True)

            with col5:
                st.markdown(f"""
                    <div class = "kpi-card">
                        <h3 style="color: #2D198E; font-size: 24px;">🏢 Alojamientos caros</h3>
                        <h1 style="color: #490a65; font-size: 48px;">{len(expensive_places)}</h1>
                        <p style="color: #6B7280; font-size: 18px;">({expensive_percentage:.1f}%)</p>
                    </div>
                """, unsafe_allow_html=True)

            st.markdown("<br><br>", unsafe_allow_html=True)
        
            # Mostramos el gráfico  
            precio_promedio_barrios = filtered_df.groupby('neighbourhood_cleansed')['converted_price'].mean()
            top5_baratos = precio_promedio_barrios.sort_values().head(5)
            top5_caros = precio_promedio_barrios.sort_values(ascending=False).head(5)

            df_dumbbell = pd.DataFrame({
                'Barrio Barato': top5_baratos.index,
                'Precio Barato': top5_baratos.values,
                'Barrio Caro': top5_caros.index,
                'Precio Caro': top5_caros.values
            })

            # Convertimos a formato largo
            df_long = pd.concat([
                df_dumbbell[['Barrio Barato', 'Precio Barato']].rename(columns={'Barrio Barato': 'Barrio', 'Precio Barato': 'Precio'}).assign(Tipo='Barato'),
                df_dumbbell[['Barrio Caro', 'Precio Caro']].rename(columns={'Barrio Caro': 'Barrio', 'Precio Caro': 'Precio'}).assign(Tipo='Caro')
            ])

            # Creamos el Dumbbell Chart
            fig = px.scatter(
                df_long,
                x="Precio",
                y="Barrio",
                color="Tipo",
                color_discrete_map={'Barato': '#172179', 'Caro': '#1C0438'},
                size=[2]*len(df_long),
                symbol="Tipo",
                symbol_map={'Barato': 'circle', 'Caro': 'diamond'},
                title="Comparativa de Precios entre Barrios (Top 5)"
            )

            # Agregamos líneas entre los pares
            for i in range(len(df_dumbbell)):
                fig.add_shape(
                    type="line",
                    x0=df_dumbbell.iloc[i]['Precio Barato'], y0=df_dumbbell.iloc[i]['Barrio Barato'],
                    x1=df_dumbbell.iloc[i]['Precio Caro'], y1=df_dumbbell.iloc[i]['Barrio Caro'],
                    line=dict(color="#002E67", width=2)
                )

            fig.update_layout(
                plot_bgcolor='white',
                xaxis=dict(showgrid=True, gridcolor='whitesmoke', title="Precio"),
                yaxis=dict(showgrid=False, title="Barrio"),
                margin=dict(t=50, l=50, r=50, b=50),
                font=dict(family="Arial", size=14, color="#111827"),
                height=600,
                showlegend=True
            )

            st.plotly_chart(fig, use_container_width=True)

##########################################################################################################################################

#CONTENIDO DE LA VISTA 3
elif View == "Modelado predictivo":
    # CSS para flipcards (mejorado)
    custom_css = """
    <style>
    .section-title {
        font-size: 25px;
        font-weight: bold;
        color: #002E67;
        border-radius: 10px;
        margin-bottom: 15px;
        padding: 4px 10px;
        text-align: center;
    }
    .section-container {
        padding: 25px;
        background-color: #F5F9FF;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 20px;
    }
    .flip-card {
        background-color: transparent;
        width: 115%;
        height: 225px;
        margin: 20px auto;
        perspective: 1000px;
    }
    .flip-card-inner {
        position: relative;
        width: 100%;
        height: 100%;
        text-align: center;
        transition: transform 0.8s;
        transform-style: preserve-3d;
    }
    .flip-card:hover .flip-card-inner {
        transform: rotateY(180deg);
    }
    .flip-card-front, .flip-card-back {
        position: absolute;
        width: 100%;
        height: 100%;
        backface-visibility: hidden;
        border-radius: 20px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        padding: 30px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        flex-direction: column;
    }
    .flip-card-front {
        background-color: #F5F9FF;
        color: #1a2e4f;
        font-size: 19px;
        border-left: 5px solid #0D47A1;
    } 
    .flip-card-back {
        color: #ecf0f1;
        transform: rotateY(180deg);
        font-size: 19px;
    }
    .card-conclusion {
        margin-top: 20px;
        background-color: #DDEEFF;
        color: #002E67;
        padding: 15px 20px;
        border-left: 5px solid #0D47A1;
        border-radius: 10px;
        font-size: 16px;
        margin-bottom: 15px;
    }
    .card-conclusion:hover {
        background: #d0e8ff;
        box-shadow: inset 0 0 8px rgba(0,0,0,0.05);
        transform: scale(1.02);
    }
    </style>
    """
    st.markdown(custom_css, unsafe_allow_html=True)

    #Librerías para regresión lineal 
    import streamlit as st
    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt
    import plotly.express as px
    import plotly.graph_objects as go
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import r2_score
    import streamlit.components.v1 as components
    from sklearn.preprocessing import LabelEncoder
    import streamlit.components.v1 as components

    # Título del dashboard
    st.markdown("<h1 style='text-align:center; color:#1E3A8A;'> AIRBNB en Toronto, Canadá 🍁</h1>", unsafe_allow_html=True)

    # Sidebar
    st.sidebar.title("DASHBOARD")
    st.sidebar.header("Sidebar: Panel de selección")

    # Sección de elección
    section = st.sidebar.selectbox(
        "Seleccione el análisis que desea ver:",
        ["Regresión lineal simple", "Regresión lineal múltiple", "Regresión logística"]
    )

    ##########################################################################
    #Limpiamos el DataFrame
    df_tipo = df.copy()

    #Convertimos los valores booleanos a numéricos 
    for col in ['host_is_superhost', 'host_identity_verified', 'instant_bookable']:
        df_tipo[col] = df_tipo[col].astype(str).replace({'f':0.0, 't':1})
        df_tipo[col] = pd.to_numeric(df_tipo[col], errors='coerce').fillna(0).astype(float)
    
    #Convertimos las variables categóricas 
    label_cols = ['property_type', 'neighbourhood_cleansed']
    encoder = LabelEncoder()

    for col in label_cols:
        df_tipo[col] = encoder.fit_transform(df_tipo[col].astype(str)).astype(float)
    ##########################################################################
    if section == "Regresión lineal simple":
        #Sidebar
        ##########################################################
        if "mostrar_info_regresion" not in st.session_state:
            st.session_state.mostrar_info_regresion = False

        if st.sidebar.button("📘 Información sobre regresión simple"):
            st.session_state.mostrar_info_regresion = not st.session_state.mostrar_info_regresion
        
        if st.session_state.mostrar_info_regresion:
            st.markdown("""
            <div style="
                background: linear-gradient(135deg, #e8f0fc, #ffffff);
                padding: 35px;
                border-radius: 20px;
                box-shadow: 4px 4px 15px rgba(0, 0, 0, 0.08);
                border: 1px solid #d6e4f5;
                font-family: 'Segoe UI', sans-serif;
                color: #2c3e50;
                line-height: 1.9;
                font-size: 17px;
                max-width: 900px;
                margin: auto;
            ">

            <h2 style="color: #1a3c6c; text-align: center; margin-top: 0;">📘 ¿Qué es la regresión lineal simple?</h2>

            <p style="text-align: center; font-size: 17px;">
            La <strong>regresión lineal simple</strong> permite predecir el valor de una variable numérica (<strong>Y</strong>) a partir de una sola variable predictora (<strong>X</strong>). Su fórmula es:
            </p>

            <div style="text-align: center; margin: 25px 0;">
                <div style="
                    font-size: 20px;
                    background-color: #d6eaf8;
                    padding: 14px 28px;
                    border-radius: 14px;
                    display: inline-block;
                    box-shadow: 2px 2px 6px rgba(0,0,0,0.07);
                    font-weight: bold;
                    border: 1px solid #aed6f1;
                    color: #1b2631;
                ">
                Y = β₀ + β₁ × X
                </div>
            </div>

            <hr style="border-top: 1px dashed #aaccee; margin-top: 30px;">

            <h4 style="color: #1f4e79;">🔍 Interpretación:</h4>
            <ul>
                <li><strong>Coeficiente (pendiente):</strong> Indica si la relación entre X e Y es positiva o negativa y qué tan fuerte es.</li>
                <li><strong>R² (R cuadrado):</strong> Mide qué tanto del cambio en Y se explica por X (varía de 0 a 1).</li>
            </ul>

            <h4 style="color: #1f4e79;">🎯 Escala del coeficiente β₁:</h4>
            <ul>
                <li><span style="color: #566573;"><strong>|β₁| &lt; 1</strong></span>: Muy débil</li>
                <li><span style="color: #5b2c6f;"><strong>1 ≤ |β₁| &lt; 10</strong></span>: Débil</li>
                <li><span style="color: #2874a6;"><strong>10 ≤ |β₁| &lt; 50</strong></span>: Moderada</li>
                <li><span style="color: #154360;"><strong>|β₁| ≥ 50</strong></span>: Fuerte</li>
            </ul>

            <h4 style="color: #1f4e79;">📈 Escala de interpretación de R²:</h4>
            <ul>
                <li><strong>R² &lt; 0.4</strong>: Poca capacidad predictiva</li>
                <li><strong>0.4 ≤ R² &lt; 0.7</strong>: Predicción moderada</li>
                <li><strong>R² ≥ 0.7</strong>: Buena predicción</li>
            </ul>

            <div style="
                background-color: #d0e8ff;
                border-left: 6px solid #0D47A1;
                padding: 14px 20px;
                border-radius: 10px;
                margin-top: 25px;
                color: black;
                font-size: 15.5px;
                box-shadow: 2px 2px 8px rgba(0,0,0,0.05);
            ">
                ⚠️ <strong>Atención:</strong> Una correlación no implica causalidad. Es fundamental considerar el contexto antes de sacar conclusiones.
            </div>
            </div>
            """, unsafe_allow_html=True)

        with st.sidebar.expander("⚙  Parámetros del modelo", expanded=True):
            # Variables disponibles
            vars_disp = ['host_response_rate', 'host_is_superhost', 'host_identity_verified', 'property_type', 'instant_bookable',
                        'accommodates', 'bathrooms', 'review_scores_cleanliness', 'minimum_nights',
                        'number_of_reviews', 'availability_365', 'neighbourhood_cleansed']
            var_indep = st.selectbox(" Variable predictoria (X):", vars_disp)

            # Tipo de habitación
            tipo_hab = df['room_type'].unique().tolist()
            tipo_select = st.multiselect(" Tipo(s) de habitación:", tipo_hab, default=tipo_hab)

        with st.sidebar.expander("👀  Opciones de visualización", expanded=True):
            # Mostrar línea de predicción (como radio)
            mostrar_pred = st.radio("¿Mostrar línea de predicción?", ["Sí", "No"], index=0) == "Sí"

            # Comparación
            comparar = st.checkbox(" Comparar tipos de habitación")
        #Cuerpo
        ##########################################################

        #Itereamos por cada tipo de habitación #05547E
        for tipo in tipo_select:
            datos = df_tipo[df_tipo['room_type'] == tipo][[var_indep, 'price']].dropna()

            x = datos[[var_indep]]
            y = datos['price']
            modelo = LinearRegression().fit(x, y)
            datos['predicted_price'] = modelo.predict(x)

            intercepto = modelo.intercept_
            coef = modelo.coef_[0]
            r2 = r2_score(y, datos['predicted_price'])

            signo = "↑ Relación positiva" if coef > 0 else "↓ Relación negativa" if coef < 0 else "Sin relación aparente"
            fuerza = "Fuerte" if abs(coef) >= 50 else "Moderada" if abs(coef) >= 10 else "Débil" if abs(coef) >= 1 else "Muy débil"
            calidad = "Buena capacidad predictiva" if r2 >= 0.7 else "Capacidad predictiva moderada" if r2 >= 0.4 else "Poca capacidad predictiva"

            # Usamos contenedor nativo de Streamlit
            st.markdown(f"""
                <div class ="section-container">
                    <div class="section-title">🔎Análisis para: {tipo}</div>
                """, unsafe_allow_html=True)

            # Columnas: gráfica y flipcard 
            col1, col2 = st.columns([2, 1])
            with col1:
                fig, ax = plt.subplots(figsize=(6, 4))
                sns.scatterplot(x=var_indep, y='price', data=datos, ax=ax, label='Datos', color='#0DA9D9')

                if mostrar_pred:
                    sns.lineplot(x=var_indep, y='predicted_price', data=datos.sort_values(by=var_indep),
                                ax=ax, color='#002E67', label='Predicción')

                ax.set_title(f"{var_indep} vs precio (CAD)")
                ax.set_ylabel("Precio (CAD)")
                ax.legend()
                st.pyplot(fig)

            with col2:
                def color_por_fuerza(fuerza):
                    if fuerza == "Muy débil":
                        return "#566573"  # gris
                    elif fuerza == "Débil":
                        return "#5b2c6f"  # morado
                    elif fuerza == "Moderada":
                        return "#2874a6"  # azul medio
                    elif fuerza == "Fuerte":
                        return "#154360"  # azul oscuro
                    else:
                        return "#0D47A1"  # color por defecto

                color_borde = color_por_fuerza(fuerza)
                color_fondo_flipcard_back = color_por_fuerza(fuerza)

                flip_html = f"""
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front" style="background-color: #eaf4fe; color: #1A3E72; font-size: 19px; border-left: 5px solid {color_borde};">
                            <p><strong>📉 Modelo:</strong></p>
                            <p>price = {intercepto:.2f} + {coef:.2f} × {var_indep}</p>
                            <p><strong>📊 Pendiente:</strong> {coef:.2f}</p>
                            <p><strong>📈 R²:</strong> {r2:.3f}</p>
                        </div>
                        <div class="flip-card-back" style="background-color: {color_fondo_flipcard_back}; color: #ecf0f1; transform: rotateY(180deg); font-size: 19px;">
                            <p><strong>Pendiente:</strong> {signo} ({fuerza})</p>
                            <p><strong>R²:</strong> {calidad}</p>
                        </div>
                    </div>
                </div>
                """

                st.markdown(flip_html, unsafe_allow_html=True)
                
                # Leyenda de colores dentro de un expander
                custom_expander = f"""
                <div style="width: 100%;">
                    <details style="
                        display: block;
                        background-color: #eaf4fe;
                        border-radius: 16px;
                        box-shadow: 2px 2px 6px rgba(0,0,0,0.08);
                        padding: 10px;
                        width: 100%;
                        margin: 10px auto 20px auto;
                        font-family: 'Arial', sans-serif;
                        color: #1A3E72;
                        ">
                        <summary style="font-size: 17px; font-weight: bold; cursor: pointer;">
                            Escala de colores
                        </summary>
                        <div style="padding-top: 12px;">
                            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                                <div style="display: flex; align-items: center;">
                                    <span style="display: inline-block; width: 20px; height: 20px; background-color: #566573; margin-right: 5px;"></span>
                                    <span><strong>Muy débil</strong></span>
                                </div>
                                <div style="display: flex; align-items: center;">
                                    <span style="display: inline-block; width: 20px; height: 20px; background-color: #5b2c6f; margin-right: 5px;"></span>
                                    <span><strong>Débil</strong></span>
                                </div>
                                <div style="display: flex; align-items: center;">
                                    <span style="display: inline-block; width: 20px; height: 20px; background-color: #2874a6; margin-right: 5px;"></span>
                                    <span><strong>Moderada</strong></span>
                                </div>
                                <div style="display: flex; align-items: center;">
                                    <span style="display: inline-block; width: 20px; height: 20px; background-color: #154360; margin-right: 5px;"></span>
                                    <span><strong>Fuerte</strong></span>
                                </div>
                            </div>
                        </div>
                    </details>
                </div>
                """

                st.markdown(custom_expander, unsafe_allow_html=True)

            # Conclusión
            st.markdown(f"""
                <div class="card-conclusion">
                    <p style="font-size: 17px; font-weight: bold; margin-bottom: 10px;">Conclusión para el tipo <u>{tipo}</u>:</strong></p>
                    <ul>
                        <li>Un aumento en <strong style="color: #0e4cc0;">{var_indep}</strong> se asocia a un cambio de <strong style="color:#0e4cc0;">{coef:.2f} CAD</strong> en el precio.</li>
                        <li>El valor de <strong style="color: #0e4cc0;">R²</strong> sugiere que el modelo tiene <strong style="color:#0e4cc0;">{calidad.lower()}</strong> para este tipo de alojamiento.</li>
                    </ul>
                </div>
            </div> <!-- fin contenedor -->
            """, unsafe_allow_html=True)

        # Mostrar comparación al final con botón
        if comparar: 
            st.markdown("---")
            st.markdown(f"""
                <div class ="section-container">
                    <div class="section-title">🥊 vs 🥊 Comparación entre tipos de habitación</div>
                """, unsafe_allow_html=True)

            resultados = []

            for tipo in tipo_select:
                datos = df_tipo[df_tipo['room_type'] == tipo][[var_indep, 'price']].dropna()
                if datos.empty:
                    continue
                x = datos[[var_indep]]
                y = datos['price']
                modelo = LinearRegression().fit(x, y)
                r2 = r2_score(y, modelo.predict(x))
                resultados.append({'Tipo': tipo, 'Pendiente': modelo.coef_[0], 'R²': r2})

            res_df = pd.DataFrame(resultados)
            res_df['Pendiente_abs'] = res_df['Pendiente'].abs()
            res_df_sorted = res_df.sort_values('Pendiente_abs', ascending=False)

            # Estilo general
            sns.set_style("whitegrid")
            sns.set_context("talk")

            # Crear figura con mejor ajuste
            fig, axes = plt.subplots(1, 2, figsize=(16, 6), constrained_layout=True)

            # Colores dinámicos
            azul_fuerte = px.colors.sequential.Blues[::-1]
            palette = azul_fuerte[:len(res_df_sorted)]

            # Gráfico interactivo de Pendiente
            fig1 = px.bar(
                res_df_sorted,
                x='Tipo',
                y='Pendiente_abs',
                title=' Pendiente por tipo de habitación',
                color='Tipo',
                color_discrete_sequence=palette,
                hover_data={'Pendiente_abs': ':.2f'}
            )
            fig1.update_layout(
                title_font_size=17,
                yaxis_title='Coeficiente',
                xaxis_title=None,
                xaxis_tickangle=15,
                showlegend=False
            )

            # Gráfico interactivo de R²
            fig2 = px.bar(
                res_df_sorted,
                x='Tipo',
                y='R²',
                title=' R² por tipo de habitación',
                color='Tipo',
                color_discrete_sequence=palette,
                hover_data={'R²': ':.2f'}
            )
            fig2.update_layout(
                title_font_size=17,
                yaxis_title='R²',
                xaxis_title=None,
                xaxis_tickangle=15,
                showlegend=False
            )

            #Mostramos el gráfico 
            col1, col2 = st.columns(2)

            with col1:
                st.plotly_chart(fig1, use_container_width=True)
            with col2:
                st.plotly_chart(fig2, use_container_width=True)

            # Encontrar el mejor tipo de habitación según la pendiente
            if not res_df.empty:
                mejor_tipo_pendiente = res_df.loc[res_df['Pendiente_abs'].idxmax()]
                mejor_tipo_r2 = res_df.loc[res_df['R²'].idxmax()]

                st.markdown(f"""
                    <div class="card-conclusion">
                        <ul>
                            <li> 📊 El tipo de habitación con la mayor <strong>influencia en el precio</strong> (mayor pendiente) es: 
                                <strong>{mejor_tipo_pendiente['Tipo']}</strong>, con un coeficiente de 
                                <strong>{float(mejor_tipo_pendiente['Pendiente']):.2f}</strong>.
                            </li>
                            <li> 📈 El tipo de habitación con el <strong>mejor ajuste predictivo</strong> (mayor R&sup2;) es: 
                                <strong>{mejor_tipo_r2['Tipo']}</strong>, con un R&sup2; de 
                                <strong>{float(mejor_tipo_r2['R²']):.3f}</strong>.
                            </li>
                        </ul>
                    </div>
                """, unsafe_allow_html=True)
    ######################################################################################################################
    elif section == "Regresión lineal múltiple":
        import statsmodels.api as sm
        from statsmodels.stats.outliers_influence import variance_inflation_factor
        from sklearn.metrics import mean_squared_error
        import streamlit.components.v1 as components
        from sklearn.linear_model import LinearRegression
        from sklearn.metrics import mean_squared_error, r2_score    
        
        #Sidebar 
        ######################################################################################
        with st.sidebar.expander("⚙  Parámetros del modelo", expanded=True):
            # Diccionario de variables dependientes disponibles
            vars_dependientes_dict = {
                "✅ host_acceptance_rate": "host_acceptance_rate",
                "⭐ host_is_superhost": "host_is_superhost",
                "🏠 host_total_listings_count": "host_total_listings_count",
                "🚪 room_type": "room_type",
                "👤 accommodates": "accommodates",
                "🛏️ bedrooms": "bedrooms",
                "💲 price": "price",
                "🔍 review_scores_value": "review_scores_value",
                "💬 reviews_per_month": "reviews_per_month"
            }
            
            #Excluimos algunas variables 
            columnas_excluidas = ['host_id', 'latitude', 'longitude', 'converted_price']

            # Creamos lista filtrada de variables independientes disponibles
            variables_disponibles = df.select_dtypes(include=[np.number]).columns.difference(columnas_excluidas).tolist()

            # Selección de variable dependiente (Y)
            var_dep_label = st.selectbox(" Variable dependiente (Y):", list(vars_dependientes_dict.keys()))
            var_dependiente = vars_dependientes_dict[var_dep_label]

            # Selección de variables independientes (X)
            var_independientes = st.multiselect("🔻 Variables independientes (X):", variables_disponibles, default=["minimum_nights"])

        with st.sidebar.expander("👀  Opciones de visualización", expanded=True):
            # Selección para mostrar predicciones
            mostrar_datos = st.checkbox("Mostrar datos reales", value=True)
            mostrar_pred = st.checkbox("Mostrar predicciones (modelo)", value=True)

            #Mostrar el HeatMap
            mostrar_heatmap = st.checkbox("Mostrar HeatMap", value=True)
        
        #Cuerpo
        #############################################################################################3
        # Agregar las predicciones al DataFrame
        df_model = df.copy()

        #Convertimos los valores booleanos a numéricos 
        bool_cols = ['host_is_superhost', 'host_identity_verified', 'instant_bookable']

        for col in bool_cols:
            df_model[col] = df_model[col].astype(str).replace({'f':0.0, 't':1})
            df_model[col] = pd.to_numeric(df_model[col], errors='coerce')
    
        #Convertimos las variables categóricas 
        label_cols = ['property_type', 'neighbourhood_cleansed', 'room_type']
        encoder = LabelEncoder()
        for col in label_cols:
            if col in df_model.columns:
                df_model[col] = encoder.fit_transform(df_model[col].astype(str))
        
        # Rellenamos los NaN con 0 en todo el DataFrame
        df_model.fillna(0, inplace=True)

        #Preparamos el modelo 
        X = df_model[var_independientes]
        y = df_model[var_dependiente]

        #Entrenamos el modelo
        modelo = LinearRegression().fit(X, y)
        y_pred = modelo.predict(X)

        #Agregamos las predicciones 
        df_model['Pred_' + var_dependiente] = y_pred

        #Metricas del modelo 

        # Calcular métricas del modelo
        r2 = r2_score(y, y_pred)
        rmse = np.sqrt(mean_squared_error(y, y_pred))
        r = np.corrcoef(y, y_pred)[0,1]

        # Funciones para interpretar los valores
        def interpretar_r2(valor):
            if valor < 0.3:
                return "🔴 R² bajo<br>Predicción débil"
            elif valor < 0.6:
                return "🟠 R² moderado<br>Predicción aceptable"
            elif valor < 0.85:
                return "🟡 R² bueno<br>Predicción sólida"
            else:
                return "🟢 R² excelente<br>Ajuste casi perfecto"

        def interpretar_r(valor):
            abs_val = abs(valor)
            if abs_val < 0.3:
                return "🔴 Correlación débil <small>entre valores reales y predichos</small>"
            elif abs_val < 0.6:
                return "🟠 Correlación moderada.<br><small>El modelo empieza a ser confiable</small>"
            elif abs_val < 0.85:
                return "🟡 Buena correlación."
            else:
                return "🟢 Correlación muy fuerte.<br><small>Predice con alta precisión</small>"

        def interpretar_rmse(valor):
            if valor > 2:
                return f"🔴 Error alto<br><small>Se equivoca ± {valor:.2f}</small>"
            elif valor > 1:
                return f"🟠 Error medio<br><small>Se equivoca ± {valor:.2f}</small>"
            else:
                return f"🟢 Buen ajuste<br><small>Se equivoca ± {valor:.2f}</small>"
        
        st.markdown("""
        <style>
        .flip-card {
            background-color: transparent;
            width: 100%;
            height: 150px;
            perspective: 1000px;
        }
        .flip-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            text-align: center;
            transition: transform 0.6s;
            transform-style: preserve-3d;
        }
        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }
        .flip-card-front, .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            backface-visibility: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            font-size: 19px;
        }
        .flip-card-front {
            background-color: #f4f6f9;
            color: #2C3E50;
            font-weight: bold;
            border-left: 5px solid #0D47A1;
        }
        .flip-card-back {
            background-color: #0D47A1;
            color: white;
            transform: rotateY(180deg);
            font-weight: normal;
        }
        </style>
        """, unsafe_allow_html=True)

        #Mostramos las metricas
        col1, col2, col3 = st.columns(3)

        with col1:
            st.markdown(f"""
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        R²<br><span style='font-size: 1.2rem;'>{r2:.3f}</span>
                    </div>
                    <div class="flip-card-back">
                        {interpretar_r2(r2)}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with col2:
            st.markdown(f"""
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        R<br><span style='font-size: 1.2rem;'>{r:.3f}</span>
                    </div>
                    <div class="flip-card-back">
                        {interpretar_r(r)}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with col3:
            st.markdown(f"""
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        RMSE<br><span style='font-size: 1.2rem;'>{rmse:.2f}</span>
                    </div>
                    <div class="flip-card-back">
                        {interpretar_rmse(rmse)}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        # 3. Gráfico: valores reales vs predichos
        if var_dependiente and var_independientes:
            st.markdown(f"""
            <div class ="section-container">
                <div class="section-title">Comparación de valores reales y predichos: {var_dependiente} vs {', '.join(var_independientes)}</div>
            """, unsafe_allow_html=True)

            # Crear el gráfico comparativo
            plt.figure(figsize=(10, 6))

            # Graficamos los datos reales si el usuario lo selecciona
            if mostrar_datos:
                sns.scatterplot(x=var_independientes[0], y=var_dependiente, data=df_model, label='Datos reales', color='#201C6D')

            # Graficamos las predicciones si el usuario lo selecciona
            if mostrar_pred:
                sns.scatterplot(x=var_independientes[0], y='Pred_' + var_dependiente, data=df_model, label='Predicciones', color='#008BD0')

            # Títulos y leyendas
            plt.title(f"Comparación entre {var_dependiente} real y predicho vs {var_independientes[0]}")
            plt.xlabel(var_independientes[0])
            plt.ylabel(var_dependiente)
            plt.legend()

            # Mostrar gráfico
            st.pyplot(plt)

        # 4. Flipcards para coeficientes
        st.markdown("---")
        st.markdown(f"""
            <div class ="section-container">
                <div class="section-title">Interpretación de coeficientes</div>
            """, unsafe_allow_html=True)

        # Tabla de coeficientes ordenados
        coef_df = pd.DataFrame({
            'Variable': X.columns,
            'Coeficiente': modelo.coef_
        }).sort_values(by='Coeficiente', key=abs, ascending=False)

        # Interpretación básica del impacto
        def interpretar_impacto(coef):
            if coef > 0.1:
                return "↗ Aumenta el precio"
            elif coef < -0.1:
                return "↘ Disminuye el precio"
            else:
                return "≈ Sin impacto significativo"

        coef_df['Impacto'] = coef_df['Coeficiente'].apply(interpretar_impacto)

        # Agregar columna de interpretación
        coef_df['Impacto'] = coef_df['Coeficiente'].apply(interpretar_impacto)

        # Tomamos los valores reales y predichos de la primera observación
        ejemplo = df_model.iloc[0]
        valor_real = ejemplo[var_dependiente]
        valor_predicho = ejemplo['Pred_' + var_dependiente]
        diferencia = valor_real - valor_predicho

        # Agregar las mismas columnas para cada variable (aunque no cambien por variable, quedan asociadas como contexto)
        coef_df['Valor real'] = valor_real
        coef_df['Valor predicho'] = valor_predicho
        coef_df['Diferencia'] = diferencia

        # Reordenamos columnas
        coef_df = coef_df[['Variable', 'Coeficiente', 'Impacto', 'Valor real', 'Valor predicho', 'Diferencia']]

        # Ordenamos por el valor absoluto del coeficiente
        coef_df = coef_df.sort_values(by='Coeficiente', key=abs, ascending=False)

        # Mostrar en Streamlit
        st.dataframe(coef_df, use_container_width=True)

        # 5. Matriz de correlación
        if mostrar_heatmap:
            st.markdown("---")
            st.markdown(f"""
                <div class ="section-container">
                    <div class="section-title"> Matriz de Correlación (HeatMap)</div>
                """, unsafe_allow_html=True)

            corr = df_model[[var_dependiente] + var_independientes].corr()
            fig_corr = px.imshow(corr, text_auto=True, color_continuous_scale='Blues')
            fig_corr.update_layout(height=400)
            #Mostramos el gráfico 
            st.plotly_chart(fig_corr, use_container_width=True)

            # 6. Conclusión dinámica
            conclusion = f"""
            <div class="card-conclusion">
                <h3>Conclusión</h3>
                <ul>
                    <li>🔍 El modelo explica aproximadamente <strong>{r2*100:.1f}%</strong> de la variabilidad en <strong>{var_dependiente}</strong>.</li>
                    <li>📉 El error medio del modelo es <strong>{rmse:.2f}</strong>.</li>
                    <li>🔧 Las variables con mayor influencia fueron: <strong>{', '.join([var for i, var in enumerate(var_independientes) if abs(modelo.coef_[i]) == max(abs(modelo.coef_))])}</strong>.</li>
                </ul>
            </div>
            """
            st.markdown(conclusion, unsafe_allow_html=True)
    ######################################################################################################################
    elif section == "Regresión logística":
        import streamlit as st
        import pandas as pd
        import numpy as np
        from sklearn.model_selection import train_test_split
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
        from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix
        from sklearn.metrics import roc_auc_score, roc_curve, classification_report
        import plotly.graph_objects as go
        from sklearn.metrics import classification_report

        # Sidebar
        ################################################################################
        if "mostrar_info_logistica" not in st.session_state:
            st.session_state.mostrar_info_logistica = False

        if st.sidebar.button("📘 Información sobre regresión logística"):
            st.session_state.mostrar_info_logistica = not st.session_state.mostrar_info_logistica

        if st.session_state.mostrar_info_logistica:
            st.markdown("""
            <div style="background-color: #e6f2ff; padding: 25px; border-radius: 16px; border-left: 6px solid #1f77b4;">
                <h2 style="color: #1a3c6c;">¿Qué es la regresión logística binaria?</h2>
                <p>La <strong>regresión logística binaria</strong> es una técnica estadística utilizada para predecir la probabilidad de que una observación pertenezca a una de dos clases posibles. En lugar de predecir un valor continuo, como en la regresión lineal, la regresión logística predice una probabilidad entre 0 y 1.</p>
                <p>La fórmula matemática es:</p>
                <p style="text-align: center; background-color: #d0e2f2; padding: 10px; border-radius: 10px;"><strong>logit(p) = β₀ + β₁ × X₁ + β₂ × X₂ + ... + βₙ × Xₙ</strong></p>
                <p>donde <em>p</em> es la probabilidad de éxito (clase 1) y los <em>β</em> son los coeficientes estimados por el modelo.</p>
                <p>La salida del modelo es una probabilidad, la cual se convierte en una predicción de clase usando un umbral, típicamente 0.5.</p>
            </div>
            """, unsafe_allow_html=True)

        # Usamos una copia para el análisis
        df_log = df.copy()

        # Diccionario de variables binarias posibles
        target_options = {
            "Host_is_superhost": {
                "column": "host_is_superhost",
                "map": {'t': 1, 'f': 0},
                "features": ['price', 'number_of_reviews', 'availability_365', 'review_scores_rating', 'host_response_time', 'host_identity_verified', 'host_response_rate']
            },
            "Instant_bookable": {
                "column": "instant_bookable",
                "map": {'t': 1, 'f': 0},
                "features": ['price', 'availability_365', 'minimum_nights', 'room_type', 'host_identity_verified', 'host_is_superhost', 'host_response_time']
            },
            "Review_scores_rating (>4.5)": {
                "column": "review_scores_rating",
                "map": lambda x: 1 if x > 4.5 else 0,
                "features": ['price', 'number_of_reviews', 'availability_365', 'room_type', 'host_response_time', 'host_is_superhost', 'reviews_per_month']
            },
            "Host_identity_verified": {
                "column": "host_identity_verified",
                "map": {'t': 1, 'f': 0},
                "features": ['price', 'room_type', 'host_response_time', 'availability_365', 'host_acceptance_rate', 'host_listings_count']
            },
            "Has_availability": {
                "column": "has_availability",
                "map": {'t': 1, 'f': 0},
                "features": ['availability_365', 'accommodates', 'price', 'room_type', 'minimum_nights']
            },
            "Host_response_time (1 hora)": {
                "column": "host_response_time",
                "map": lambda x: 1 if x == 'within an hour' else 0,
                "features": ['price', 'host_identity_verified', 'review_scores_rating', 'availability_365', 'host_is_superhost', 'host_response_rate', 'number_of_reviews']
            },
            "Accommodates (4+ personas)": {
                "column": "accommodates",
                "map": lambda x: 1 if x >= 4 else 0,
                "features": ['price', 'room_type', 'availability_365', 'number_of_reviews', 'beds']
            }
        }

        # Selección de variable objetivo
        target_label = st.sidebar.selectbox("Variable objetivo (binaria):", list(target_options.keys()))
        target_info = target_options[target_label]
        col = target_info["column"]

        st.markdown(f"""
                <div class ="section-container">
                    <div class="section-title"> Variable objetivo: <strong>{target_label}</strong></div>
                """, unsafe_allow_html=True)

        # Preparar los datos
        df_log = df_log[df_log[col].notna()]
        df_log['target'] = df_log[col].map(target_info["map"]) if isinstance(target_info["map"], dict) else df_log[col].apply(target_info["map"])

        # Filtros para valores no deseados
        for col in ["host_is_superhost", "host_identity_verified", "has_availability"]:
            df_log = df_log[(df_log[col] != "False") & df_log[col].notna()]

        # Selección de variables predictoras
        available_features = target_info["features"]
        selected_features = st.sidebar.multiselect("Variables predictoras (X):", available_features, default=available_features)

        # Cuerpo
        ################################################################################
        # Predicciones
        X_raw = df_log[selected_features].fillna(0)
        X_dummies = pd.get_dummies(X_raw, drop_first=True)
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_dummies)
        y = df_log['target']

        # División train/test
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

        # Entrenamiento del modelo
        model = LogisticRegression(max_iter=1000)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1]

        # Métricas
        accuracy = model.score(X_test, y_test)
        roc_auc = roc_auc_score(y_test, y_proba)

        # Generar interpretación basada en el valor de accuracy
        if accuracy >= 0.90:
            acc_interp = "Excelente exactitud: el modelo predice muy bien."
        elif accuracy >= 0.75:
            acc_interp = "Buena exactitud: el modelo funciona correctamente."
        elif accuracy >= 0.60:
            acc_interp = "Aceptable: puede mejorar, pero es funcional."
        else:
            acc_interp = "Baja exactitud: el modelo necesita mejoras."

        # Interpretación personalizada para ROC AUC
        if roc_auc >= 0.90:
            auc_interp = "Excelente discriminación entre clases."
        elif roc_auc >= 0.75:
            auc_interp = "Buena capacidad para distinguir clases."
        elif roc_auc >= 0.60:
            auc_interp = "Moderada: el modelo podría mejorar."
        else:
            auc_interp = "Débil: rendimiento apenas mejor que al azar."

        # Estilo y estructura de flipcards
        st.markdown("""
        <style>
        .flip-card-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 30px;
            margin-bottom: 40px;
        }
        .flip-card {
            background-color: transparent;
            width: 260px;
            height: 180px;
            perspective: 1000px;
        }
        .flip-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            transition: transform 0.7s;
            transform-style: preserve-3d;
        }
        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }
        .flip-card-front, .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 14px;
            backface-visibility: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 16px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        }
        .flip-card-front {
            background-color: #f4f6f9;
            color: #2C3E50;
            font-weight: bold;
            border-left: 5px solid #0D47A1;
        }
        .flip-card-back {
            background-color: #002e67;
            color: white;
            transform: rotateY(180deg);
            font-weight: normal;
        }
        </style>
        """, unsafe_allow_html=True)

        with st.expander("¿Cómo se evalúa el modelo?"):
            st.markdown("""
            <ul>
                <li><strong>Accuracy (Exactitud):</strong> Mide qué porcentaje de las predicciones hechas por el modelo fueron correctas. Es decir, cuántas veces el modelo acertó comparado con el total de predicciones. Un valor más alto es mejor, pero no siempre refleja completamente la calidad del modelo si las clases están desbalanceadas.</li>
                <li><strong>ROC AUC (Área Bajo la Curva ROC):</strong> Es una métrica que mide qué tan bien el modelo distingue entre las dos clases (por ejemplo, entre "sí" y "no"). Cuanto más cerca esté de 1, mejor será el modelo. Si es cercano a 0.5, significa que el modelo no tiene mejor desempeño que una predicción aleatoria.</li>
            </ul>
            """, unsafe_allow_html=True)

        # Mostrar las flipcards con interpretaciones dinámicas
        st.markdown(f"""
        <div class="flip-card-container">
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        <h4>Exactitud</h4>
                        <p style="font-size: 22px; font-weight: bold;">{accuracy:.2%}</p>
                    </div>
                    <div class="flip-card-back">
                        <h5>Interpretación</h5>
                        <p style="font-size: 14px; text-align: center;">{acc_interp}</p>
                    </div>
                </div>
            </div>
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        <h4>ROC AUC</h4>
                        <p style="font-size: 22px; font-weight: bold;">{roc_auc:.2f}</p>
                    </div>
                    <div class="flip-card-back">
                        <h5>Interpretación</h5>
                        <p style="font-size: 14px; text-align: center;">{auc_interp}</p>
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Convertir el reporte de clasificación a DataFrame para mejor visualización
        report_dict = classification_report(y_test, y_pred, output_dict=True)
        report_df = pd.DataFrame(report_dict).transpose().round(2)

        # Ordenar columnas relevantes si existen
        if 'support' in report_df.columns:
            report_df = report_df[['precision', 'recall', 'f1-score', 'support']]

        # Título informativo
        st.markdown("""
        <div style="margin-top: 30px; margin-bottom: 10px;">
            <h4 style="color:#1a3c6c;">📄 Reporte de Clasificación</h4>
            <p style="font-size:15px;">Este reporte muestra las métricas clave para cada clase:</p>
        </div>
        """, unsafe_allow_html=True)

        # Mostrar el DataFrame con estilo
        st.dataframe(report_df.style
                    .background_gradient(cmap='Blues', axis=0)
                    .format(precision=2),
                    height=350, use_container_width=True)

        # Matriz de confusión
        cm = confusion_matrix(y_test, y_pred)
        fig_cm = go.Figure(data=go.Heatmap(
            z=cm,
            x=['Predicho 0', 'Predicho 1'],
            y=['Real 0', 'Real 1'],
            colorscale='Blues',
            zmin=0,
            zmax=cm.max()
        ))
        fig_cm.update_layout(title="Matriz de Confusión", xaxis_title="Predicción", yaxis_title="Real")
        st.plotly_chart(fig_cm)

        # Coeficientes + odds ratio
        with st.expander("📈 ¿Qué significan los coeficientes?"):
            st.markdown("""
            <ul>
                <li>Si el coeficiente β es <strong>positivo</strong>: A medida que la variable aumenta, la probabilidad del evento (clase 1) <strong>aumenta</strong>.</li>
                <li>Si el coeficiente β es <strong>negativo</strong>: A medida que la variable aumenta, la probabilidad del evento <strong>disminuye</strong>.</li>
                <li><strong>Odds Ratio</strong>: Es el efecto multiplicativo de una variable sobre las probabilidades del evento.</li>
            </ul>
            """, unsafe_allow_html=True)

        coef = model.coef_[0]
        feature_names = X_dummies.columns
        odds_ratio = np.exp(coef)

        coef_df = pd.DataFrame({
            'Variable': feature_names,
            'Coeficiente': coef,
            'Odds Ratio': odds_ratio,
            'Interpretación': ['↑ Aumenta la probabilidad' if c > 0 else '↓ Disminuye la probabilidad' for c in coef]
        }).sort_values(by='Coeficiente', ascending=False)

        st.markdown("*Influencia de las variables en la probabilidad:*")
        st.dataframe(coef_df)

        coef_fig = go.Figure(data=[go.Bar(
            x=coef_df['Variable'],
            y=coef_df['Coeficiente'],
            marker=dict(color=coef_df['Coeficiente'], colorscale='RdBu')
        )])
        coef_fig.update_layout(title="Coeficientes del Modelo Logístico", xaxis_title="Variable", yaxis_title="Coeficiente")
        st.plotly_chart(coef_fig)
##############################################################################
